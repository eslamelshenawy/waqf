<?php


return [
    'sales_invoices' => 'فواتير المبيعات',
];