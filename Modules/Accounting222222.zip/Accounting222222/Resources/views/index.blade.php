@extends('accounting::layouts.master')

@section('content')

@endsection
