<script src="{{adminUrl()}}/styles/js/vendor/jquery-3.3.1.min.js"></script>
<script src="{{adminUrl()}}/styles/js/vendor/bootstrap.bundle.min.js"></script>
<script src="{{adminUrl()}}/styles/js/es5/script.min.js"></script>
</body>

</html>
