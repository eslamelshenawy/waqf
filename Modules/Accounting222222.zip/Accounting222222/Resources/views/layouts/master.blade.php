@include("accounting::layouts.header")
<div id="app" style="min-height: 800px;">
    @yield('content')
</div>
@include("accounting::layouts.footer")

