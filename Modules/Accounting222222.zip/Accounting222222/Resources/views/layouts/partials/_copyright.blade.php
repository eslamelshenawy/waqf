<div class="app-footer">
    <div class="row">
        <div class="col-md-9">
            <p>حقوق الملكيه 2020 محفوظه <a href="#">لوقف ،</a> جميع الحقوق محفوظه</p>
        </div>
    </div>
    <div class="footer-bottom border-top pt-3 d-flex flex-column flex-sm-row align-items-center">
        <a class="btn btn-primary text-white btn-rounded" href="{{url('accounting/accounts')}}">
            لوحة التحكم
        </a>
        <span class="flex-grow-1"></span>
        <div class="d-flex align-items-center">
            <img class="logo" alt="">
            <div>
                <p class="m-0">© 2020 </p>
                <p class="m-0">جميع الحقوق محفوظة</p>
            </div>
        </div>
    </div>
</div>
