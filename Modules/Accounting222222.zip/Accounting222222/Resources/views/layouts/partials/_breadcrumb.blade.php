<div class="breadcrumb" style="background-color: #FFF;">
    <h1>Waqf</h1>
    <ul>
        <li><a href="{{ url('/accounting') }}">Accounting System</a>&nbsp;</li>
        <li>{{ session()->has('current_page') ? session()->get('current_page') : '' }}</li>
    </ul>
</div>
<div class="separator-breadcrumb border-top"></div>

