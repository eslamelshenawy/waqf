<div class="w3-container">
    <div id="id01" class="w3-modal">
        <div class="w3-modal-content w3-animate-bottom w3-card-4">
            <div class="card" >
                <div class="card-header p-3" style="height: 40px;">
                    <button onclick="document.getElementById('id01').style.display='none'"
                            class="w3-button w3-display-topright">&times;</button>
                </div>

                <div class="clearfix"></div>


                <div class="card-body">
                    <form>
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">First</label>
                                    <inpu class="form-control" id="name" type="text" name="d" style="z-index: 1000000 !important;"/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dd">First</label>
                                    <inpu class="form-control" id="dd" type="text" name="d" />
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">First</label>
                                    <inpu class="form-control" id="name" type="text" name="d" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dd">First</label>
                                    <inpu class="form-control" id="dd" type="text" name="d" />
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">First</label>
                                    <inpu class="form-control" id="name" type="text" name="d" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="dd">First</label>
                                    <inpu class="form-control" id="dd" type="text" name="d" />
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>