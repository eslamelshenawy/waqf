<?php


namespace Modules\Accounting\Traits;


trait ShouldMakeJournal
{

}