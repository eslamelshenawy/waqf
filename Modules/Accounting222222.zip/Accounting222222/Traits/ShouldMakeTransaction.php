<?php


namespace Modules\Accounting\Traits;


trait ShouldMakeTransaction
{
    public function make()
    {
        return true;
    }
}