<?php

namespace Modules\Accounting\Repositories\Cheque;

interface ChequeRepositoryInterface
{

}