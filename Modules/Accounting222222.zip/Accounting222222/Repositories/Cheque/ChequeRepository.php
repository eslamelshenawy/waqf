<?php


namespace Modules\Accounting\Repositories\Cheque;


class ChequeRepository implements ChequeRepositoryInterface
{

}