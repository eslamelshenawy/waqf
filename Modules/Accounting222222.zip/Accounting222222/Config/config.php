<?php

return [
    'name' => 'Accounting',
    'locale' => 'ar',
    'fallback_locale' => 'en'
];
